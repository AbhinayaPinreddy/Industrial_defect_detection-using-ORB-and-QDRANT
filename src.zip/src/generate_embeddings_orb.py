import cv2
import os
import numpy as np

DATASET_PATH = r"C:\Users\abhin\OneDrive\Desktop\factory_Defect_detection\datasets\NEU-DET\train\images"
EMBEDDINGS = []

orb = cv2.ORB_create(nfeatures=500)

def image_to_embedding(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        return None

    keypoints, descriptors = orb.detectAndCompute(img, None)
    if descriptors is None:
        return np.zeros(32)

    # Convert variable descriptors → fixed-size vector
    return descriptors.mean(axis=0)

for defect_type in os.listdir(DATASET_PATH):
    defect_folder = os.path.join(DATASET_PATH, defect_type)
    if not os.path.isdir(defect_folder):
        continue

    for img_name in os.listdir(defect_folder):
        img_path = os.path.join(defect_folder, img_name)
        emb = image_to_embedding(img_path)

        if emb is not None:
            EMBEDDINGS.append({
                "vector": emb.tolist(),
                "defect_type": defect_type,
                "image_path": img_path
            })

print("Total embeddings:", len(EMBEDDINGS))
print("Embedding size:", len(EMBEDDINGS[0]["vector"]))

import json

with open("orb_embeddings.json", "w") as f:
    json.dump(EMBEDDINGS, f)

print("Embeddings saved to orb_embeddings.json")


