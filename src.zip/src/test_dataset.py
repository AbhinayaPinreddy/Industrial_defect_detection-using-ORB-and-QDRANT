import os
from PIL import Image
import matplotlib.pyplot as plt

DATASET_PATH = r"C:\Users\abhin\OneDrive\Desktop\factory_Defect_detection\datasets\NEU-DET\train\images"

classes = os.listdir(DATASET_PATH)
print("Defect types:", classes)

img_path = os.path.join(DATASET_PATH, classes[0], os.listdir(os.path.join(DATASET_PATH, classes[0]))[0])
img = Image.open(img_path)

plt.imshow(img)
plt.axis("off")
plt.show()
