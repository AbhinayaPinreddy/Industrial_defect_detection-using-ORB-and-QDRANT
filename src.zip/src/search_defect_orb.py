import cv2
import numpy as np
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue


# ----------------------------------
# Step 1: ORB feature extractor
# ----------------------------------
orb = cv2.ORB_create(nfeatures=500)

def image_to_embedding(image_path):
    """
    Convert an image into a fixed-size ORB embedding (32-dim)
    """
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Image not found: {image_path}")

    keypoints, descriptors = orb.detectAndCompute(img, None)

    if descriptors is None:
        return np.zeros(32)

    return descriptors.mean(axis=0)


# ----------------------------------
# Step 2: Choose a query image
# ----------------------------------
query_image =r"C:\Users\abhin\OneDrive\Desktop\factory_Defect_detection\datasets\NEU-DET\validation\images\crazing\crazing_241.jpg"
import os





query_vector = image_to_embedding(query_image).tolist()


# ----------------------------------
# Step 3: Connect to Qdrant
# ----------------------------------
client = QdrantClient(path="qdrant_data")


# ----------------------------------
# Step 4: Search similar defects
# ----------------------------------
results = client.search(
    collection_name="factory_defects_orb",
    query_vector=query_vector,
    limit=5,
    query_filter=Filter(
        must=[
            FieldCondition(
                key="severity",
                match=MatchValue(value="high")
            ),
            FieldCondition(
                key="shift",
                match=MatchValue(value="night")
            )
        ]
    )
)



# ----------------------------------
# Step 5: Display results
# ----------------------------------
print("\n🔍 Similar defects found:\n")

for i, r in enumerate(results, start=1):
    print(f"{i}. Defect type : {r.payload['defect_type']}")
    print(f"   Severity    : {r.payload['severity']}")
    print(f"   Shift       : {r.payload['shift']}")
    print(f"   Image path  : {r.payload['image_path']}\n")

from sop_rules import SOP_MAP

print("\n🛠 Recommended SOPs:\n")
for r in results:
    defect = r.payload["defect_type"]
    print(defect, "→", SOP_MAP.get(defect, "No SOP available"))
