SOP_MAP = {
    "scratches": "Inspect rollers, polish surface, reduce friction",
    "crazing": "Reduce thermal stress and control cooling rate",
    "pitted_surface": "Check corrosion exposure and clean surface",
    "patches": "Inspect material flow and recalibrate machine",
    "inclusion": "Check raw material purity",
    "rolled-in-scale": "Improve descaling before rolling"
}
