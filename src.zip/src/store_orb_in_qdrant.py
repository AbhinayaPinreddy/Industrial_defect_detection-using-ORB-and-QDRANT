import json
import uuid
import random
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct

# Load ORB embeddings
with open("orb_embeddings.json", "r") as f:
    data = json.load(f)

# Start local Qdrant
client = QdrantClient(path="qdrant_data")

# Create collection
from qdrant_client.models import PointStruct, VectorParams, Distance

client.recreate_collection(
    collection_name="factory_defects_orb",
    vectors_config=VectorParams(
        size=32,
        distance=Distance.COSINE
    )
)


points = []

for item in data:
    points.append(
        PointStruct(
            id=str(uuid.uuid4()),
            vector=item["vector"],
            payload={
                "defect_type": item["defect_type"],
                "severity": random.choice(["low", "medium", "high"]),
                "shift": random.choice(["day", "night"]),
                "image_path": item["image_path"]
            }
        )
    )

client.upsert(
    collection_name="factory_defects_orb",
    points=points
)

print("All ORB embeddings stored in Qdrant successfully")
client.close()

